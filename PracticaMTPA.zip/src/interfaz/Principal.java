package interfaz;

public class Principal {
    public static void main(String args[]){
        new Ventana().setVisible(true);
    }
}    
