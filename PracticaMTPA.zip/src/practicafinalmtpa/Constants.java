package practicafinalmtpa;

public interface Constants {
    public static String INDEX_PATH=".\\index.html";
    public static String FILES_PATH=".\\ficheros\\";
    public static String BD_PATH=".\\baseDatos\\";
    public static String RECYCLE_BIN_PATH=".\\papelera\\";
    public static String MIME_DB=".\\conf\\MIMES.txt";
    public static String IPS_BL=".\\conf\\IP-BlackList.txt";
    public static String LOG_PATH=".\\log\\";
    public static String PET_USERS=LOG_PATH+"peticionesUsers.log";
}
